<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "my_project_database";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO `users` (`id`, `name`, `psw`, `psw-repeat`, `role`, `class`, `Departments`, `Contact`, `gender`) VALUES (NULL, 'Omini Jadhav', 'Omini@123', 'Omini@123', 'Student', 'TE', 'CS', '9307005541', 'female');";

if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
