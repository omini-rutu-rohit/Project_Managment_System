<?php

//Login Logout system created by @Rohit

include("connection.php");
?>

<form action="" method="POST">
	Email <input type="text" name="email"><br><br>

	Password<input type="text" name="psw"><br><br>

	<input type="submit" name="submit" value="Login"> <br><br>

	
</form>

<?php

if(isset($_POST['submit']))
{
	$email = $_POST['email'];
	$psw = $_POST['psw'];

	//$query = "SELECT * FROM users WHERE email = '$email' && psw = '$psw'";
	$query = "SELECT * FROM USERS" WHERE email = '$email' && psw = '$psw'";

	$data = mysqli_query($conn, $query);

	$total = mysqli_num_rows($data);
	//echo $total;

	if($total == 1)
	{
		//echo "Login Successful";
		header('location:home.php')
	}
	else
	{
		echo "Login Failed";
	}
}

?>
