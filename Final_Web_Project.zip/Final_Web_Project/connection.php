<?php 
// 1. database credentials
$host = "localhost";
$username = "root";
$password = "";
$db_name = "project_schedule";

$con = mysqli_connect($host,$username,$password,$db_name);

if($con){
    ?>
        <script>
            alert("connection successful");
        </script>
    <?php
}else {
    
    ?>
        <script>
            alert(" no connection ");
    <?php
}

?>